﻿namespace Flex_Trainer
{
    partial class traner_feedback
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.guna2GradientPanel1 = new Guna.UI2.WinForms.Guna2GradientPanel();
            this.guna2HtmlLabel1 = new Guna.UI2.WinForms.Guna2HtmlLabel();
            this.label1 = new System.Windows.Forms.Label();
            this.flowLayoutPanel1 = new System.Windows.Forms.FlowLayoutPanel();
            this.card_feedback1 = new Flex_Trainer.card_feedback();
            this.card_feedback2 = new Flex_Trainer.card_feedback();
            this.card_feedback3 = new Flex_Trainer.card_feedback();
            this.card_feedback4 = new Flex_Trainer.card_feedback();
            this.card_feedback5 = new Flex_Trainer.card_feedback();
            this.card_feedback6 = new Flex_Trainer.card_feedback();
            this.guna2GradientPanel1.SuspendLayout();
            this.flowLayoutPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guna2GradientPanel1
            // 
            this.guna2GradientPanel1.Controls.Add(this.guna2HtmlLabel1);
            this.guna2GradientPanel1.Controls.Add(this.label1);
            this.guna2GradientPanel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.guna2GradientPanel1.Location = new System.Drawing.Point(0, 0);
            this.guna2GradientPanel1.Name = "guna2GradientPanel1";
            this.guna2GradientPanel1.Size = new System.Drawing.Size(1260, 104);
            this.guna2GradientPanel1.TabIndex = 1;
            // 
            // guna2HtmlLabel1
            // 
            this.guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent;
            this.guna2HtmlLabel1.Location = new System.Drawing.Point(27, 59);
            this.guna2HtmlLabel1.Name = "guna2HtmlLabel1";
            this.guna2HtmlLabel1.Size = new System.Drawing.Size(177, 22);
            this.guna2HtmlLabel1.TabIndex = 3;
            this.guna2HtmlLabel1.Text = "umerghaforr@gmail.com";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Arial", 12F, System.Drawing.FontStyle.Bold);
            this.label1.Location = new System.Drawing.Point(22, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(174, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Umer Ghafoor";
            // 
            // flowLayoutPanel1
            // 
            this.flowLayoutPanel1.AutoScroll = true;
            this.flowLayoutPanel1.Controls.Add(this.card_feedback1);
            this.flowLayoutPanel1.Controls.Add(this.card_feedback2);
            this.flowLayoutPanel1.Controls.Add(this.card_feedback3);
            this.flowLayoutPanel1.Controls.Add(this.card_feedback4);
            this.flowLayoutPanel1.Controls.Add(this.card_feedback5);
            this.flowLayoutPanel1.Controls.Add(this.card_feedback6);
            this.flowLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel1.Location = new System.Drawing.Point(0, 104);
            this.flowLayoutPanel1.Margin = new System.Windows.Forms.Padding(12);
            this.flowLayoutPanel1.Name = "flowLayoutPanel1";
            this.flowLayoutPanel1.Padding = new System.Windows.Forms.Padding(12);
            this.flowLayoutPanel1.Size = new System.Drawing.Size(1260, 786);
            this.flowLayoutPanel1.TabIndex = 16;
            // 
            // card_feedback1
            // 
            this.card_feedback1.Location = new System.Drawing.Point(15, 15);
            this.card_feedback1.Name = "card_feedback1";
            this.card_feedback1.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback1.TabIndex = 0;
            // 
            // card_feedback2
            // 
            this.card_feedback2.Location = new System.Drawing.Point(15, 167);
            this.card_feedback2.Name = "card_feedback2";
            this.card_feedback2.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback2.TabIndex = 1;
            // 
            // card_feedback3
            // 
            this.card_feedback3.Location = new System.Drawing.Point(15, 319);
            this.card_feedback3.Name = "card_feedback3";
            this.card_feedback3.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback3.TabIndex = 2;
            // 
            // card_feedback4
            // 
            this.card_feedback4.Location = new System.Drawing.Point(15, 471);
            this.card_feedback4.Name = "card_feedback4";
            this.card_feedback4.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback4.TabIndex = 3;
            // 
            // card_feedback5
            // 
            this.card_feedback5.Location = new System.Drawing.Point(15, 623);
            this.card_feedback5.Name = "card_feedback5";
            this.card_feedback5.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback5.TabIndex = 4;
            // 
            // card_feedback6
            // 
            this.card_feedback6.Location = new System.Drawing.Point(15, 775);
            this.card_feedback6.Name = "card_feedback6";
            this.card_feedback6.Size = new System.Drawing.Size(1017, 146);
            this.card_feedback6.TabIndex = 5;
            // 
            // traner_feedback
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.flowLayoutPanel1);
            this.Controls.Add(this.guna2GradientPanel1);
            this.Name = "traner_feedback";
            this.Size = new System.Drawing.Size(1260, 890);
            this.guna2GradientPanel1.ResumeLayout(false);
            this.guna2GradientPanel1.PerformLayout();
            this.flowLayoutPanel1.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private Guna.UI2.WinForms.Guna2GradientPanel guna2GradientPanel1;
        private Guna.UI2.WinForms.Guna2HtmlLabel guna2HtmlLabel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel1;
        private card_feedback card_feedback1;
        private card_feedback card_feedback2;
        private card_feedback card_feedback3;
        private card_feedback card_feedback4;
        private card_feedback card_feedback5;
        private card_feedback card_feedback6;
    }
}
